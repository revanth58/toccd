x = 25
y = 13
sum = x + y
diff = x - y
value = sum + 10
